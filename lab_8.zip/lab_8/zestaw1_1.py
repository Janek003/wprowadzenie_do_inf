a = [int(input("liczba: ")) for _ in range(4)]

for l in range(3):
    print(a[l]/a[3])