n = int(input("n: "))
a = [int(input("liczba: ")) for _ in range(n)]

print(max(a))
print(min(a))
